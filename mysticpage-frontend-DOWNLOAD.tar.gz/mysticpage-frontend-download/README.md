# Mysticpage Frontend

Windows Installation Bot - Web Dashboard

## Quick Start

```bash
npm install
cp .env.local.example .env.local
# Edit .env.local dengan backend URL Anda
npm run dev
```

Open http://localhost:3000

## Build Production

```bash
npm run build
```

Upload folder `/out` ke server.

## Features

- Login/Register dengan Telegram ID
- Dashboard dengan statistik
- Form instalasi Windows
- History & tracking
- Dark mode
- Responsive design

## Tech Stack

- Next.js 14 + TypeScript
- Tailwind CSS + shadcn/ui
- Zustand (state management)

Untuk setup lengkap, lihat SETUP.md
